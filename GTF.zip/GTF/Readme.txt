The code contains all the eight methods used for comparison in our paper.
If you use this code, please cite our paper as follows:

Jiayi Ma, Chen Chen, Chang Li, and Jun Huang. "Infrared and visible image fusion via gradient transfer and total variation minimization", Information Fusion, 31, pp. 100-109, Sept. 2016.