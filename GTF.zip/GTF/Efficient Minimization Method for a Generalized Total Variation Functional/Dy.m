function[u] = Dy(v)

  u = [diff(v); zeros(1,size(v,2))];
    
return

