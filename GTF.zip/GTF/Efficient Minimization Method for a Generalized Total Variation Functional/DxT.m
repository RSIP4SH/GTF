function[u] = DxT(v)

  u = DyT(v')';

return
